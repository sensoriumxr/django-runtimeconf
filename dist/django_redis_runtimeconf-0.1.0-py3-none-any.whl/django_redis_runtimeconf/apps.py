from django.apps import AppConfig


class RuntimeconfConfig(AppConfig):
    name = 'runtimeconf'
